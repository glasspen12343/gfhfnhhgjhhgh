const siteConfig = {
  recipientName: "Kiwi",
  passcode: "0107",
  letterTitle: "Happy Boyfriend's Day, my Spider-Man",
  photos: [
    "assets/photo-1.jpg"
  ],
  music: "assets/music.mp3",
  messages: ["DO YOU EVER", "HEAR ME", "CALLING?"],
  letterBody: [
    "My Kiwi,",
    "If I could turn every little moment with you into a photograph, I would fill an entire scrapbook with us. You make ordinary days feel like pages I want to keep forever.",
    "Thank you for being my safe place, my favorite smile, and the person I want beside me when life gets loud. No superpowers needed — you already make my world softer.",
    "So here is a tiny handmade corner of the internet, just for you. Keep it close, my Spider-Man. ♥"
  ]
};

const scenes = ["passcode","wall","choose","letter","message","collage"];
let current = 0;
let digits = "";
let messageTimer = null;
let music = null;

const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];

function svgSpider(label=""){
  return `<div class="web-line"></div><div class="chibi" aria-label="Cute hanging Spider-Man decoration" role="img"><div class="head"><div class="mask-lines"></div></div><div class="body"></div><div class="arm left"></div><div class="arm right"></div><div class="flower">✿</div></div>${label ? `<div class="hang-tag">${label}</div>` : ""}`;
}
function webBg(){return `<div class="web-wall" aria-hidden="true"><span class="ring1"></span><span class="ring2"></span><span class="ring3"></span><span class="radials"></span></div><div class="web-corner" aria-hidden="true"></div>`}

function renderPasscode(){
  $("#scene-passcode").innerHTML = `${webBg()}<div class="passcode-wrap">
    <button class="spider-badge" id="badge" aria-label="Spider web decoration"></button>
    <h1 class="passcode-title">ENTER PASSCODE</h1>
    <div class="dots" id="dots" aria-label="Passcode progress"><span class="dot"></span><span class="dot"></span><span class="dot"></span><span class="dot"></span></div>
    <div class="error-note" id="errorNote">try again, love ♡</div>
    <div class="keypad" aria-label="Numeric keypad">
      ${key(1)}${key(2,"ABC")}${key(3,"DEF")}
      ${key(4,"GHI")}${key(5,"JKL")}${key(6,"MNO")}
      ${key(7,"PQRS")}${key(8,"TUV")}${key(9,"WXYZ")}
      ${key(0)}
    </div>
    <button class="cancel" id="cancel">cancel</button>
  </div>`;
  $$(".key", $("#scene-passcode")).forEach(b=>b.addEventListener("click",()=>enterDigit(b.dataset.digit)));
  $("#cancel").addEventListener("click",()=>{digits="";updateDots();});
}
function key(n,letters=""){return `<button class="key ${n===0?"zero":""}" data-digit="${n}" aria-label="${n}"><strong>${n}</strong><small>${letters}</small></button>`}
function updateDots(){
  $$(".dot",$("#scene-passcode")).forEach((d,i)=>d.classList.toggle("filled",i<digits.length));
}
function enterDigit(n){
  if(digits.length>=4)return;
  digits += String(n); updateDots();
  startAudio();
  if(digits.length===4){
    if(digits===siteConfig.passcode){
      $("#badge").animate([{transform:"rotate(-3deg) scale(1)"},{transform:"rotate(-3deg) scale(1.13)"},{transform:"rotate(-3deg) scale(1)"}],{duration:420,easing:"ease-out"});
      setTimeout(()=>go(1),520);
    }else{
      const dots=$("#dots"); dots.classList.remove("shake"); void dots.offsetWidth; dots.classList.add("shake");
      const e=$("#errorNote"); e.classList.add("show");
      setTimeout(()=>{digits="";updateDots();e.classList.remove("show")},700);
    }
  }
}

function wallScene(extra=false){
  return `${webBg()}<div class="wall-content">
    <button class="web-sticker" aria-label="Spider web sticker"><span>✦</span></button>
    <div class="hanging h1" data-go="2">${svgSpider("for you")}</div>
    <div class="hanging h2" data-go="2">${svgSpider("my love")}</div>
    <div class="hanging h3" data-go="2">${svgSpider("kiwi")}</div>
    <div class="hanging edge" aria-hidden="true">${svgSpider("")}</div>
    <div class="wall-copy">choose one my love</div>
    <div class="wall-hint">tap a little spider to open your scrapbook</div>
    <div class="corner-note">made with a little web + a lot of love</div>
    <div class="tiny-heart th1">♥</div><div class="tiny-heart th2">♥</div><div class="tiny-heart th3">♥</div>
  </div>`;
}
function renderWall(){$("#scene-wall").innerHTML=wallScene(); $$("[data-go]",$("#scene-wall")).forEach(el=>el.addEventListener("click",()=>go(2)));}
function renderChoose(){
  $("#scene-choose").innerHTML=`${webBg()}<div class="wall-content">
    <button class="back-btn" data-back>back</button>
    <div class="hanging h1" data-go="3">${svgSpider("one")}</div>
    <div class="hanging h2" data-go="3">${svgSpider("two")}</div>
    <div class="hanging h3" data-go="3">${svgSpider("three")}</div>
    <div class="wall-copy">choose one my love</div>
    <div class="wall-hint">there is no wrong choice ♡</div>
    <div class="tiny-heart th1">♥</div><div class="tiny-heart th2">♥</div><div class="tiny-heart th3">♥</div>
  </div>`;
  $$("[data-go]",$("#scene-choose")).forEach(el=>el.addEventListener("click",()=>go(3)));
  $("[data-back]",$("#scene-choose")).addEventListener("click",()=>go(1));
}

function renderLetter(){
  const body=siteConfig.letterBody.map((p,i)=>`<p class="letter-reveal" style="opacity:0;transform:translateY(8px);transition-delay:${i*170}ms">${p.replaceAll("♥","<span class='letter-heart'>♥</span>")}</p>`).join("");
  $("#scene-letter").innerHTML=`<div class="letter-stage">
    <button class="back-btn" data-back>back</button>
    <div class="photo-side">
      <div class="paper-bg"></div><div class="tape one"></div><div class="tape two"></div>
      <div class="burst">SPENS!</div><div class="photo-doodle">♡</div>
      <figure class="polaroid"><img src="${siteConfig.photos[0]}" alt="Couple illustration from the supplied reference"><figcaption class="caption">our little universe</figcaption></figure>
      <div class="paper-strip"></div>
    </div>
    <div class="letter-wrap">
      <article class="letter-paper">
        <div class="letter-inner">
          <div class="letter-kicker">a tiny page from our scrapbook</div>
          <h2 class="letter-title">${siteConfig.letterTitle}</h2>
          <p class="letter-to">Dear ${siteConfig.recipientName},</p>
          <div class="letter-body">${body}</div>
          <div class="signature">always yours, ♥</div>
        </div>
      </article>
    </div>
  </div><button class="next-btn" id="letterNext">turn the page →</button>`;
  $("[data-back]",$("#scene-letter")).addEventListener("click",()=>go(2));
  $("#letterNext").addEventListener("click",()=>go(4));
}
function revealLetter(){
  setTimeout(()=>{$$(".letter-reveal",$("#scene-letter")).forEach(p=>{p.style.opacity="1";p.style.transform="translateY(0)"})},220);
}

function renderMessage(){
  $("#scene-message").innerHTML=`<div class="message-frame"><div class="message-word small" data-word="0">DO YOU EVER</div><div class="message-word big" data-word="1">HEAR ME</div><div class="message-word mid" data-word="2">CALLING?</div><div class="message-heart">♥</div><div class="message-note">for the person I would find in every universe.</div></div><button class="next-btn" id="messageNext" style="background:#181818;border-color:#444">continue →</button>`;
  $("#messageNext").addEventListener("click",()=>go(5));
}
function startMessage(){
  clearTimeout(messageTimer); const words=$$(".message-word",$("#scene-message")); words.forEach(w=>w.classList.remove("visible"));
  words.forEach((w,i)=>setTimeout(()=>w.classList.add("visible"),350+i*950));
}

function polaroid(i,cls){return `<figure class="final-polaroid ${cls}"><img src="${siteConfig.photos[i%siteConfig.photos.length]}" alt="Couple scrapbook photo ${i+1}"></figure>`}
function renderCollage(){
  $("#scene-collage").innerHTML=`<div class="collage-back"><div class="web-corner"></div><div class="news n1"><strong>THE DAILY LOVE</strong>Local hero spotted making one person smile again. More on page ∞.</div><div class="news n2"><strong>BREAKING NEWS</strong>KIWI officially remains someone's favorite human.</div><div class="news n3"><strong>SCRAPBOOK NOTE</strong>Keep the tiny moments. They become the big ones.</div><div class="news n4"><strong>CLASSIFIED</strong>One heart. One web. One very lucky love.</div><div class="comic-red cr1">THWIP!</div><div class="comic-red cr2">♥ ALWAYS</div></div>
  <section class="board" aria-label="Final scrapbook collage">
    <div class="board-label">for my Kiwi — keep this page forever</div>
    ${polaroid(0,"fp1")}
    <div class="sticker spider s1">🕷️</div><div class="sticker spider s2">🕸️</div><div class="sticker spider s3">🕷️</div>
    <div class="sticker heart sh1">♥</div><div class="sticker heart sh2">♥</div><div class="sticker heart sh3">♥</div><div class="sticker cat-sticker">🐱♡</div>
    <div class="final-note">love you.</div>
  </section>
  <div class="collage-controls"><button class="small-control" id="restart">open again</button><button class="small-control" id="musicToggle">music</button></div>`;
  $("#restart").addEventListener("click",()=>{digits="";updateDots();go(0)});
  $("#musicToggle").addEventListener("click",toggleMusic);
}

function go(index){
  if(index<0||index>=scenes.length)return;
  const old=$("#scene-"+scenes[current]); const next=$("#scene-"+scenes[index]);
  old.classList.remove("is-active"); old.setAttribute("aria-hidden","true"); next.classList.add("is-active"); next.setAttribute("aria-hidden","false"); current=index;
  if(index===3)revealLetter(); if(index===4)startMessage();
}

function startAudio(){
  if(!music){
    music=new Audio(siteConfig.music); music.loop=true; music.volume=.16;
    music.addEventListener("error",()=>{music=null});
  }
  if(music){const p=music.play(); if(p&&p.catch)p.catch(()=>{});}
}
function toggleMusic(){
  if(!music)startAudio();
  if(!music)return;
  if(music.paused)music.play().catch(()=>{});else music.pause();
}

renderPasscode(); renderWall(); renderChoose(); renderLetter(); renderMessage(); renderCollage();
window.addEventListener("keydown",e=>{
  if(current===0){if(/^[0-9]$/.test(e.key))enterDigit(Number(e.key));if(e.key==="Escape"){digits="";updateDots()}}
  else if(e.key==="ArrowRight"||e.key==="Enter"){
    if(current===1)go(2); else if(current===2)go(3); else if(current===3)go(4); else if(current===4)go(5);
  } else if(e.key==="ArrowLeft"||e.key==="Escape"){
    if(current>0)go(current-1);
  }
});
let touchX=null;
window.addEventListener("touchstart",e=>{touchX=e.changedTouches[0].clientX},{passive:true});
window.addEventListener("touchend",e=>{if(touchX==null)return;const dx=e.changedTouches[0].clientX-touchX;touchX=null;if(Math.abs(dx)<70)return;if(dx<0&&current>0)go(current+1);if(dx>0&&current>0)go(current-1)},{passive:true});
