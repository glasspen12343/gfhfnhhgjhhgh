# KIWI — Spider-Man Love Scrapbook

A fixed-screen, scene-based romantic digital card for Kiwi.

## Run it

This version is intentionally dependency-free.

1. Keep the folder structure intact.
2. Double-click `index.html` to open it in a browser, or use VS Code Live Server.
3. Enter the private passcode on the opening keypad.
4. Click/tap the hanging Spider-Man decorations to move through the scrapbook.

## Files

- `index.html` — scene shell
- `styles.css` — full visual system, paper textures, responsive layout, animations
- `script.js` — scene state, keypad, navigation, letter reveal and interactions
- `assets/reference.png` — the supplied reference image
- `assets/photo-1.jpg` … `photo-4.jpg` — crops made from the supplied reference image and used as the current photo content

## Personalize

Edit the `siteConfig` object at the top of `script.js`:

- `recipientName`
- `passcode`
- `letterTitle`
- `photo`
- `letterBody`
- `music`

To add music, place an MP3 at `assets/music.mp3`. Audio begins after a user interaction, which avoids browser autoplay restrictions.

## Navigation

- Password screen: keypad, keyboard digits, Cancel/Escape
- Desktop: Arrow Left / Arrow Right / Enter / Escape
- Mobile: tap and swipe left/right
- No normal vertical scrolling is used for the story scenes.

## Note about the supplied image

The supplied four-panel couple illustration is currently used as the scrapbook's photo material so the first working version is visually populated. Replace the four `photo` paths with your own photographs when ready; the Polaroid framing preserves aspect ratio.
